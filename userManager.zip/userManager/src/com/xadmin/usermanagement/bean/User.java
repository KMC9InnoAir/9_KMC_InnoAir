package com.xadmin.usermanagement.bean;

/**
 * User.java
 * This is a model class represents a User entity
 */

public class User {
	protected String email;
	protected String uname;
	protected String upass;
	
	public User() {
	}
	
	public User(String email, String uname, String upass) {
		super();
		this.email = email;
		this.uname = uname;
		this.upass = upass;
	}
	
	public String getemail() {
		return email;
	}
	
	public void setemail(String email) {
		this.email = email;
	}
	
	public String getuname() {
		return uname;
	}
	
	public void setuname(String uname) {
		this.uname = uname;
	}
	
	public String getupass() {
		return upass;
	}
	
	public void setupass(String upass) {
		this.upass = upass;
	}
}