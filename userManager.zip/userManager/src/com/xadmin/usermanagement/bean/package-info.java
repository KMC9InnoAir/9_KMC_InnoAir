/**
 * 
 */
/**
 * @author hrusa
 *
 */
package com.xadmin.usermanagement.bean;